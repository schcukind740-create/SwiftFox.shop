using System.Globalization;

namespace ShoeShop.Web.Services;

public static class Money
{
    private static readonly CultureInfo Russian = CultureInfo.GetCultureInfo("ru-RU");

    public static string Format(decimal amount) =>
        amount.ToString(amount % 1 == 0 ? "N0" : "N2", Russian) + "\u00a0₽";
}
