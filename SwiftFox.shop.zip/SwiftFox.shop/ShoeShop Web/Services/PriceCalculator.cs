using ShoeShop.Web.Models;

namespace ShoeShop.Web.Services;

/// <summary>
/// Бизнес-правила цены и остатков.
/// Скидка 25% даётся на товары, которые никто не заказывал в прошлом календарном месяце.
/// Остаток 3 пары и меньше считается малым и подсвечивается в каталоге.
/// </summary>
public static class PriceCalculator
{
    public const decimal DiscountRate = 0.25m;
    public const int LowStockLimit = 3;

    public static bool HasDiscount(bool orderedLastMonth) => !orderedLastMonth;

    public static decimal FinalPrice(decimal price, bool orderedLastMonth)
    {
        if (!HasDiscount(orderedLastMonth))
            return price;

        return Math.Round(price * (1 - DiscountRate), 2, MidpointRounding.AwayFromZero);
    }

    /// <summary>Первый день прошлого месяца и первый день текущего (граница не включается).</summary>
    public static (DateOnly From, DateOnly To) PreviousMonth(DateOnly today)
    {
        var currentMonthStart = new DateOnly(today.Year, today.Month, 1);
        return (currentMonthStart.AddMonths(-1), currentMonthStart);
    }

    public static StockLevel GetStockLevel(int stock)
    {
        if (stock <= 0) return StockLevel.None;
        if (stock <= LowStockLimit) return StockLevel.Low;
        return StockLevel.Enough;
    }
}
