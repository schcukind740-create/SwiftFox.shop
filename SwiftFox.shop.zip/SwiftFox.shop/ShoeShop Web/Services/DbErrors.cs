using System.Net.Sockets;
using Npgsql;

namespace ShoeShop.Web.Services;

/// <summary>Перевод ошибок PostgreSQL в понятные пользователю сообщения.</summary>
public static class DbErrors
{
    public static string Describe(Exception ex) => ex switch
    {
        PostgresException { SqlState: "3D000" } =>
            "База данных shoeshop не найдена. Создайте её скриптами из папки database.",
        PostgresException { SqlState: "28P01" or "28000" } =>
            "PostgreSQL отклонил имя пользователя или пароль. Проверьте строку подключения в appsettings.json.",
        PostgresException { SqlState: "23514" } =>
            "Данные не прошли проверку в базе: проверьте даты и количество.",
        PostgresException { SqlState: "23503" } =>
            "Запись связана с другими данными и не может быть изменена.",
        PostgresException { SqlState: "23505" } =>
            "Такая запись уже существует.",
        PostgresException pg =>
            $"Ошибка базы данных: {pg.MessageText}",
        NpgsqlException { InnerException: SocketException } or NpgsqlException { InnerException: TimeoutException } =>
            "Нет связи с сервером PostgreSQL. Проверьте, что служба запущена.",
        NpgsqlException =>
            "Не удалось выполнить запрос к базе данных. Попробуйте ещё раз.",
        InvalidOperationException => ex.Message,
        _ => "Непредвиденная ошибка: " + ex.Message
    };
}
