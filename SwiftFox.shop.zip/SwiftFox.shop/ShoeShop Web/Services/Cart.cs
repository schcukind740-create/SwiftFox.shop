using System.Text.Json;
using ShoeShop.Web.Data;
using ShoeShop.Web.Models;

namespace ShoeShop.Web.Services;

public record BasketItem(int ProductId, int Size, int Quantity);

public static class Cart
{
    private const string Key = "cart.sizes";
    private const string LegacyKey = "cart";
    private const string CheckoutKeyName = "cart.checkout";

    public static List<BasketItem> Get(ISession session)
    {
        if (session.GetString(Key) is { } current)
            return JsonSerializer.Deserialize<List<BasketItem>>(current) ?? [];
        if (session.GetString(LegacyKey) is not { } old) return [];
        return (JsonSerializer.Deserialize<Dictionary<int, int>>(old) ?? [])
            .Select(item => new BasketItem(item.Key, 42, item.Value)).ToList();
    }

    public static List<CartLine> LoadLines(ISession session, ProductRepository products)
    {
        var basket = Get(session);
        var byId = products.GetByIds(basket.Select(item => item.ProductId).Distinct())
            .ToDictionary(product => product.Id);
        return basket.Where(item => byId.ContainsKey(item.ProductId))
            .Select(item => new CartLine { Product = byId[item.ProductId], Size = item.Size, Quantity = item.Quantity })
            .ToList();
    }

    public static int Count(ISession session) => Get(session).Sum(item => item.Quantity);
    public static int Quantity(ISession session, int productId, int size) =>
        Get(session).FirstOrDefault(item => item.ProductId == productId && item.Size == size)?.Quantity ?? 0;

    public static void Set(ISession session, int productId, int size, int quantity)
    {
        var basket = Get(session);
        basket.RemoveAll(item => item.ProductId == productId && item.Size == size);
        if (quantity > 0) basket.Add(new BasketItem(productId, size, quantity));
        session.SetString(Key, JsonSerializer.Serialize(basket));
        session.Remove(LegacyKey);
        session.SetString(CheckoutKeyName, Guid.NewGuid().ToString());
    }

    public static void Clear(ISession session)
    {
        session.Remove(Key);
        session.Remove(LegacyKey);
        session.Remove(CheckoutKeyName);
    }

    public static Guid CheckoutKey(ISession session)
    {
        if (Guid.TryParse(session.GetString(CheckoutKeyName), out var existing))
            return existing;

        var key = Guid.NewGuid();
        session.SetString(CheckoutKeyName, key.ToString());
        return key;
    }
}
