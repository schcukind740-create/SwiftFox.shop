using ShoeShop.Web.Models;

namespace ShoeShop.Web.Services;

/// <summary>Текущий пользователь, хранится в сессии после входа.</summary>
public class Account
{
    public const string RoleAdmin = "Администратор";
    public const string RoleManager = "Менеджер";
    public const string RoleGuest = "Гость";

    private const string KeyId = "user.id";
    private const string KeyName = "user.name";
    private const string KeyRole = "user.role";
    private const string KeyInitials = "user.initials";

    public int UserId { get; private init; }
    public string FullName { get; private init; } = "";
    public string Role { get; private init; } = "";
    public string Initials { get; private init; } = "";

    public bool IsSignedIn => Role != "";
    public bool IsGuest => Role == RoleGuest;
    public bool IsAdmin => Role == RoleAdmin;
    public bool IsStaff => Role is RoleAdmin or RoleManager;
    public bool CanOrder => IsSignedIn && !IsGuest;

    public static Account FromSession(ISession session) => new()
    {
        UserId = session.GetInt32(KeyId) ?? 0,
        FullName = session.GetString(KeyName) ?? "",
        Role = session.GetString(KeyRole) ?? "",
        Initials = session.GetString(KeyInitials) ?? ""
    };

    public static void SignIn(ISession session, SignedInUser user)
    {
        session.Clear();
        UpdateSession(session, user);
    }

    public static void UpdateSession(ISession session, SignedInUser user)
    {
        session.SetInt32(KeyId, user.Id);
        session.SetString(KeyName, user.FullName);
        session.SetString(KeyRole, user.Role);
        session.SetString(KeyInitials, user.Initials);
    }

    public static void SignInAsGuest(ISession session)
    {
        session.Clear();
        session.SetInt32(KeyId, 0);
        session.SetString(KeyName, "Гость");
        session.SetString(KeyRole, RoleGuest);
    }

    public static void SignOut(ISession session) => session.Clear();
}
