using ShoeShop.Web.Services;

namespace ShoeShop.Web.Models;

public enum StockLevel
{
    None,
    Low,
    Enough
}

public class Product
{
    public int Id { get; init; }
    public string Article { get; init; } = "";
    public string Name { get; init; } = "";
    public string Category { get; init; } = "";
    public string Manufacturer { get; init; } = "";
    public string Supplier { get; init; } = "";
    public string Unit { get; init; } = "";
    public decimal Price { get; init; }
    public IReadOnlyList<ShoeSize> Sizes { get; init; } = [];
    public int Stock => Sizes.Sum(size => size.Stock);
    public int StockFor(int size) => Sizes.FirstOrDefault(item => item.Eu == size)?.Stock ?? 0;
    public int CategoryId { get; init; }
    public int ManufacturerId { get; init; }
    public int SupplierId { get; init; }
    public string? Description { get; init; }
    public string? Photo { get; init; }

    /// <summary>Были ли заказы этого товара в прошлом календарном месяце.</summary>
    public bool OrderedLastMonth { get; init; }

    public bool HasDiscount => PriceCalculator.HasDiscount(OrderedLastMonth);
    public decimal FinalPrice => PriceCalculator.FinalPrice(Price, OrderedLastMonth);
    public StockLevel Level => PriceCalculator.GetStockLevel(Stock);

    public string PhotoUrl => string.IsNullOrWhiteSpace(Photo)
        ? "/images/picture.webp"
        : "/images/products/" + Uri.EscapeDataString(Photo);
}

public record Category(int Id, string Name);

public record PickupPoint(int Id, string Address);

public record OrderStatus(int Id, string Name);

public record Client(int Id, string FullName);

public record SignedInUser(int Id, string FullName, string Role, string Initials);

public class OrderRow
{
    public int Id { get; init; }
    public DateOnly OrderDate { get; init; }
    public DateOnly DeliveryDate { get; init; }
    public string Client { get; init; } = "";
    public string Address { get; init; } = "";
    public string Status { get; init; } = "";
    public int PickupCode { get; init; }
    public int Pairs { get; init; }
    public decimal Total { get; init; }
}

public class OrderDetails
{
    public int Id { get; init; }
    public int UserId { get; init; }
    public string Client { get; init; } = "";
    public int PointId { get; init; }
    public int StatusId { get; init; }
    public string Status { get; init; } = "";
    public string PaymentMethod { get; init; } = "pickup";
    public DateOnly OrderDate { get; init; }
    public DateOnly DeliveryDate { get; init; }
    public int PickupCode { get; init; }
    public List<OrderLine> Lines { get; init; } = new();
    public decimal Total => Lines.Sum(l => l.Sum);
}

public class OrderLine
{
    public int ProductId { get; init; }
    public string Article { get; init; } = "";
    public string Name { get; init; } = "";
    public int Size { get; init; }
    public int Quantity { get; init; }
    public decimal Price { get; init; }
    public decimal Sum => Price * Quantity;
}

public class CartLine
{
    public Product Product { get; init; } = null!;
    public int Size { get; init; }
    public int Quantity { get; init; }
    public decimal Sum => Product.FinalPrice * Quantity;
}
