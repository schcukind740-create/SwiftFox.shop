namespace ShoeShop.Web.Models;

public record ShoeSize(int Eu, int Stock);
public record ReferenceItem(int Id, string Name);
public record Member(int Id, string Login, string FirstName, string LastName, string? Patronymic,
    int RoleId, string Role, bool Active)
{
    public string FullName => string.Join(" ", new[] { LastName, FirstName, Patronymic }.Where(part => !string.IsNullOrWhiteSpace(part)));
}
public record InventoryMovement(DateTime At, string Article, string Product, int Size, int Delta, int Stock, string Reason);
public record DailyOrders(DateOnly Date, int Count);
