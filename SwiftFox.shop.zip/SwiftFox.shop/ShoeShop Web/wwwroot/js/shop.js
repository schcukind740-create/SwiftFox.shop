const catalog = document.querySelector('#catalog-controls');
const results = document.querySelector('#catalog-results');

function modelWord(number) {
    if (number % 100 >= 11 && number % 100 <= 14) return 'моделей';
    if (number % 10 === 1) return 'модель';
    return number % 10 >= 2 && number % 10 <= 4 ? 'модели' : 'моделей';
}

if (catalog && results) {
    const countLabel = document.querySelector('#result-count');
    let request;
    let timer;

    function updateCount() {
        const count = results.querySelector('[data-result-count]')?.dataset.resultCount;
        countLabel.textContent = count === undefined ? '' : `${count} ${modelWord(Number(count))}`;
    }

    async function refresh() {
        request?.abort();
        const controller = new AbortController();
        request = controller;
        const params = new URLSearchParams(new FormData(catalog));
        for (const [key, value] of [...params]) {
            if (!value || (['category', 'brand'].includes(key) && value === '0')) params.delete(key);
        }
        const publicUrl = new URL(catalog.action);
        publicUrl.search = params;
        history.replaceState(null, '', publicUrl);
        const fragmentUrl = new URL(catalog.dataset.resultsUrl, location.origin);
        for (const [key, value] of params) fragmentUrl.searchParams.set(key, value);
        results.setAttribute('aria-busy', 'true');
        try {
            const response = await fetch(fragmentUrl, { signal: controller.signal });
            const content = await response.text();
            if (!response.ok) throw new Error(response.status === 503 ? content : 'Не удалось обновить каталог.');
            if (!controller.signal.aborted) results.innerHTML = content;
        } catch (error) {
            if (controller.signal.aborted) return;
            const notice = document.createElement('p');
            notice.className = 'notice is-error';
            notice.setAttribute('role', 'alert');
            notice.textContent = error.message;
            results.replaceChildren(notice);
        } finally {
            if (!controller.signal.aborted) {
                results.setAttribute('aria-busy', 'false');
                updateCount();
            }
        }
    }

    function schedule() {
        clearTimeout(timer);
        request?.abort();
        timer = setTimeout(refresh, 160);
    }

    catalog.addEventListener('submit', event => { event.preventDefault(); schedule(); });
    for (const field of catalog.querySelectorAll('select')) field.addEventListener('change', schedule);
    for (const field of catalog.querySelectorAll('input:not([type=hidden])')) field.addEventListener('input', schedule);
    catalog.querySelector('[data-close-price]')?.addEventListener('click', event => {
        const menu = event.target.closest('details');
        menu.open = false;
        menu.querySelector('summary')?.focus();
    });
    updateCount();
    if (location.hash === '#catalog-search') catalog.elements.q.focus({ preventScroll: true });
}

const checkout = document.querySelector('[data-checkout]');
if (checkout) {
    const card = checkout.querySelector('[data-card-entry]');
    const number = card.querySelector('[data-card-number]');
    const date = card.querySelector('[data-card-date]');
    const code = card.querySelector('[data-card-code]');
    const error = card.querySelector('[data-card-error]');
    const action = checkout.querySelector('[data-checkout-submit]');
    const dialog = document.querySelector('[data-payment-dialog]');
    let processing = false;

    const digits = (value, max) => value.replace(/[^0-9]/g, '').slice(0, max);
    number.addEventListener('input', () => { number.value = digits(number.value, 19).match(/.{1,4}/g)?.join(' ') ?? ''; });
    date.addEventListener('input', () => { date.value = digits(date.value, 4).match(/.{1,2}/g)?.join('/') ?? ''; });
    code.addEventListener('input', () => { code.value = digits(code.value, 4); });
    card.addEventListener('input', () => { error.hidden = true; });
    dialog.addEventListener('cancel', event => { if (processing) event.preventDefault(); });

    function changePayment() {
        const demo = checkout.elements.payment.value === 'demo';
        card.hidden = !demo;
        action.textContent = demo ? action.dataset.payLabel : 'Подтвердить заказ';
        error.hidden = true;
    }

    checkout.querySelector('[data-demo-option]').hidden = false;
    checkout.addEventListener('change', event => {
        if (event.target.name === 'payment') changePayment();
    });
    changePayment();

    function showError(text, target) {
        error.textContent = text;
        error.hidden = false;
        target.focus();
    }

    checkout.addEventListener('submit', event => {
        if (checkout.elements.payment.value !== 'demo') return;
        event.preventDefault();
        if (processing) return;
        if (digits(number.value, 19).length < 13) {
            showError('Введите от 13 до 19 цифр.', number);
            return;
        }
        const month = Number(date.value.slice(0, 2));
        if (date.value.length !== 5 || month < 1 || month > 12) {
            showError('Введите срок действия в формате ММ/ГГ.', date);
            return;
        }
        if (code.value.length < 3) {
            showError('Введите 3 или 4 цифры.', code);
            return;
        }
        error.hidden = true;
        processing = true;
        action.disabled = true;
        dialog.showModal();
        setTimeout(() => {
            number.value = date.value = code.value = '';
            checkout.elements.demoResult.value = 'approved';
            HTMLFormElement.prototype.submit.call(checkout);
        }, 1050);
    });
}

document.addEventListener('input', event => {
    if (event.target.matches('[data-digits]')) event.target.value = event.target.value.replace(/[^0-9]/g, '');
});
document.addEventListener('change', event => {
    if (event.target.matches('[data-autosubmit]')) event.target.form.requestSubmit();
    if (event.target.matches('[data-size-supply]')) {
        const note = event.target.form.querySelector('[data-size-note]');
        if (note) note.textContent = `Размер EU ${event.target.value} · доступно ${event.target.dataset.sizeSupply}`;
    }
});
document.addEventListener('submit', event => {
    const message = event.target.dataset.confirm;
    if (message && !window.confirm(message)) event.preventDefault();
});
