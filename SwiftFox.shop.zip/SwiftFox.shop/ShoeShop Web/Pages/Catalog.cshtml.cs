using Microsoft.AspNetCore.Mvc;
using ShoeShop.Web.Data;
using ShoeShop.Web.Models;
using ShoeShop.Web.Services;

namespace ShoeShop.Web.Pages;

[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class CatalogModel(ProductRepository products, LookupRepository lookups, OperationsRepository operations) : ShopPage
{
    protected override bool AllowAnonymous => true;
    public IReadOnlyList<Product> Products { get; private set; } = [];
    public IReadOnlyList<Category> Categories { get; private set; } = [];
    public IReadOnlyList<ReferenceItem> Brands { get; private set; } = [];

    public IActionResult OnGet(string? q, int category, string? sort, bool sale, decimal? min, decimal? max, int brand)
    {
        TryDb(() =>
        {
            Categories = lookups.Categories();
            Brands = operations.Brands();
            Products = products.Search(q, category, sort, sale, min, max, brand);
        }, redirecting: false);
        return Page();
    }

    public IActionResult OnGetResults(string? q, int category, string? sort, bool sale, decimal? min, decimal? max, int brand)
    {
        try { return Partial("_ProductList", products.Search(q, category, sort, sale, min, max, brand)); }
        catch (Npgsql.NpgsqlException ex) { return StatusCode(503, DbErrors.Describe(ex)); }
    }
}
