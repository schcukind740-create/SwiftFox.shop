using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using Npgsql;
using ShoeShop.Web.Data;
using ShoeShop.Web.Models;
using ShoeShop.Web.Services;

namespace ShoeShop.Web.Pages;

[RequestFormLimits(MultipartBodyLengthLimit = 6_000_000)]
public class StockModel(OperationsRepository operations, ProductRepository products, LookupRepository lookups,
    IWebHostEnvironment environment) : StaffPage
{
    public List<Product> Products { get; private set; } = [];
    public List<InventoryMovement> Movements { get; private set; } = [];
    public List<Category> Categories { get; private set; } = [];
    public List<ReferenceItem> Brands { get; private set; } = [];
    public List<ReferenceItem> Suppliers { get; private set; } = [];
    public Product? Selected { get; private set; }
    public bool Adding { get; private set; }

    public void OnGet(int? id, bool add = false) => TryDb(() =>
    {
        Products = products.GetAll();
        Movements = operations.Movements();
        Selected = id.HasValue ? Products.FirstOrDefault(product => product.Id == id) : null;
        Adding = Account.IsAdmin && add;
        if (!Account.IsAdmin || (!Adding && Selected is null)) return;
        Categories = lookups.Categories();
        Brands = operations.Brands();
        Suppliers = operations.Suppliers();
    }, redirecting: false);

    public async Task<IActionResult> OnPostSaveAsync(int id, string? article, string? name,
        int category, int brand, int supplier, string? price, string? description,
        IFormFile? image, int? initialSize, int initialStock)
    {
        if (!Account.IsAdmin) return StatusCode(403);
        string? saved = null;
        try
        {
            if (!ModelState.IsValid || string.IsNullOrWhiteSpace(name) || name.Length > 160 ||
                string.IsNullOrWhiteSpace(article) || article.Length > 60 ||
                category <= 0 || brand <= 0 || supplier <= 0 || description?.Length > 2000 ||
                initialSize is < 35 or > 49 || initialStock is < 0 or > 999 ||
                !decimal.TryParse(price?.Replace(',', '.'), NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out var amount) ||
                amount < 0 || amount > 9_999_999 || amount != decimal.Round(amount, 2))
                throw new InvalidOperationException("Проверьте артикул, название, цену и остаток.");
            saved = await SaveImageAsync(image);
            var productId = operations.SaveProduct(id, article.Trim(), name.Trim(), category, brand, supplier,
                amount, description?.Trim(), saved, initialSize, initialStock);
            Notify("Карточка товара сохранена.");
            return RedirectToPage(new { id = productId });
        }
        catch (Exception ex) when (ex is NpgsqlException or InvalidOperationException or IOException or UnauthorizedAccessException)
        {
            if (saved is not null) System.IO.File.Delete(Path.Combine(environment.WebRootPath,"images","products",saved));
            Fail(ex is IOException or UnauthorizedAccessException ? "Не удалось сохранить изображение." : DbErrors.Describe(ex));
            return RedirectToPage(new { id = id == 0 ? (int?)null : id, add = id == 0 });
        }
    }

    public IActionResult OnPostSetStock(int id, int size, int stock)
    {
        if (!Account.IsAdmin) return StatusCode(403);
        if (!ModelState.IsValid || size is < 35 or > 49 || stock is < 0 or > 999)
            Fail("Размер должен быть от 35 до 49, остаток — целое число от 0 до 999.");
        else if (TryDb(() => operations.SetStock(id, size, stock)))
            Notify("Остаток обновлён.");
        return RedirectToPage(new { id });
    }

    private async Task<string?> SaveImageAsync(IFormFile? image)
    {
        if (image is null || image.Length == 0) return null;
        if (image.Length > 5_000_000) throw new InvalidOperationException("Фото должно весить до 5 МБ.");
        await using var source = image.OpenReadStream();
        var header = new byte[12];
        if (await source.ReadAtLeastAsync(header, header.Length, false) < header.Length)
            throw new InvalidOperationException("Загрузите JPG, PNG или WebP.");
        var ext = header[0] == 0xff && header[1] == 0xd8 && header[2] == 0xff ? ".jpg"
            : header.AsSpan(0,8).SequenceEqual(new byte[] { 137,80,78,71,13,10,26,10 }) ? ".png"
            : header.AsSpan(0,4).SequenceEqual("RIFF"u8) && header.AsSpan(8,4).SequenceEqual("WEBP"u8) ? ".webp" : null;
        if (ext is null) throw new InvalidOperationException("Загрузите JPG, PNG или WebP.");
        var name = Guid.NewGuid().ToString("N") + ext;
        source.Position = 0;
        var file = Path.Combine(environment.WebRootPath, "images", "products", name);
        try
        {
            await using var destination = System.IO.File.Open(file, FileMode.CreateNew);
            await source.CopyToAsync(destination);
        }
        catch (IOException)
        {
            System.IO.File.Delete(file);
            throw;
        }
        return name;
    }
}
