using ShoeShop.Web.Data;
using ShoeShop.Web.Models;

namespace ShoeShop.Web.Pages;

public class DashboardModel(OperationsRepository operations, OrderRepository orders, ProductRepository products) : StaffPage
{
    public List<OrderRow> Orders { get; private set; } = [];
    public List<DailyOrders> Week { get; private set; } = [];
    public List<Product> Products { get; private set; } = [];
    public int MemberCount { get; private set; }

    public void OnGet() => TryDb(() =>
    {
        Orders = orders.List(0);
        Week = operations.Week();
        Products = products.GetAll();
        if (Account.IsAdmin) MemberCount = operations.Members().Count(member => member.Active);
    }, redirecting: false);
}
