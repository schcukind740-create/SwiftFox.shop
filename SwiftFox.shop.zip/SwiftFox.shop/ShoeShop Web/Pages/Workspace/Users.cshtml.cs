using Microsoft.AspNetCore.Mvc;
using ShoeShop.Web.Data;
using ShoeShop.Web.Models;

namespace ShoeShop.Web.Pages;

public class UsersModel(OperationsRepository operations) : StaffPage
{
    protected override string[] AllowedRoles => [Services.Account.RoleAdmin];
    public List<Member> Members { get; private set; } = [];
    public List<ReferenceItem> Roles { get; private set; } = [];
    public Member? Selected { get; private set; }
    public bool Adding { get; private set; }
    public bool Archive { get; private set; }

    public void OnGet(int? id, bool add = false, bool archive = false) => TryDb(() =>
    {
        Members = operations.Members();
        Roles = operations.Roles();
        Selected = Members.FirstOrDefault(member => member.Id == id);
        Adding = add;
        Archive = archive;
    }, redirecting: false);

    public IActionResult OnPostSave(int id, string? login, string? firstName, string? lastName, string? patronymic, int roleId)
    {
        if (!ModelState.IsValid || string.IsNullOrWhiteSpace(login) || login.Length > 100 ||
            !login.All(c => char.IsAsciiLetterOrDigit(c) || c is '.' or '_' or '-' or '@') ||
            string.IsNullOrWhiteSpace(firstName) || firstName.Length > 80 ||
            string.IsNullOrWhiteSpace(lastName) || lastName.Length > 80 || patronymic?.Length > 80 || roleId <= 0)
        {
            Fail("Проверьте логин, имя, фамилию и роль.");
            return RedirectToPage(new { id = id > 0 ? (int?)id : null, add = id == 0 });
        }
        if (!TryDb(() => operations.SaveMember(id, login.Trim(), firstName.Trim(), lastName.Trim(), patronymic?.Trim(), roleId, Account.UserId)))
            return RedirectToPage(new { id = id > 0 ? (int?)id : null, add = id == 0 });
        Notify("Пользователь сохранён.");
        return RedirectToPage();
    }

    public IActionResult OnPostRemove(int id)
    {
        TryDb(() => Notify(operations.RemoveMember(id, Account.UserId)
            ? "Доступ отключён. Пользователь перенесён в архив." : "Пользователь удалён."));
        return RedirectToPage();
    }

    public IActionResult OnPostRestore(int id)
    {
        if (TryDb(() => operations.RestoreMember(id, Account.UserId))) Notify("Доступ восстановлен.");
        return RedirectToPage();
    }
}
