using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using ShoeShop.Web.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Npgsql;
using ShoeShop.Web.Services;

namespace ShoeShop.Web.Pages;

/// <summary>
/// Базовый класс страниц: проверяет вход и роль, выводит сообщения пользователю
/// и перехватывает ошибки при работе с базой данных.
/// </summary>
public abstract class ShopPage : PageModel
{
    public Account Account { get; private set; } = new();

    /// <summary>Страница открывается без входа (только окно авторизации).</summary>
    protected virtual bool AllowAnonymous => false;

    /// <summary>Если задано, страница доступна только этим ролям.</summary>
    protected virtual string[]? AllowedRoles => null;

    protected virtual string? SignInNext => null;

    public override void OnPageHandlerExecuting(PageHandlerExecutingContext context)
    {
        var session = HttpContext.Session;
        Account = Account.FromSession(session);
        if (Account.UserId > 0)
        {
            try
            {
                var member = HttpContext.RequestServices.GetRequiredService<UserRepository>().FindById(Account.UserId);
                if (member is null) Account.SignOut(session);
                else if (member.Role != Account.Role || member.FullName != Account.FullName || member.Initials != Account.Initials) Account.UpdateSession(session, member);
                Account = Account.FromSession(session);
            }
            catch (NpgsqlException)
            {
                context.Result = new StatusCodeResult(503);
                return;
            }
        }

        if (!AllowAnonymous && !Account.IsSignedIn)
        {
            context.Result = RedirectToPage("/SignIn", new { next = SignInNext });
            return;
        }

        if (AllowedRoles != null && !AllowedRoles.Contains(Account.Role))
        {
            Fail("Вашей роли недоступен этот раздел.");
            context.Result = RedirectToPage("/Index");
        }
    }

    /// <summary>Сообщение после перенаправления.</summary>
    protected void Notify(string text) => TempData["Message"] = text;

    /// <summary>Ошибка после перенаправления.</summary>
    protected void Fail(string text) => TempData["Error"] = text;

    /// <summary>Ошибка на текущей странице.</summary>
    protected void ShowError(string text) => ViewData["Error"] = text;

    /// <summary>Выполняет действие с базой; при ошибке показывает сообщение и возвращает false.</summary>
    protected bool TryDb(Action action, bool redirecting = true)
    {
        try
        {
            action();
            return true;
        }
        catch (Exception ex) when (ex is NpgsqlException or InvalidOperationException)
        {
            if (redirecting) Fail(DbErrors.Describe(ex));
            else ShowError(DbErrors.Describe(ex));
            return false;
        }
    }
}
