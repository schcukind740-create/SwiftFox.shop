using Microsoft.AspNetCore.Mvc;
using ShoeShop.Web.Data;
using ShoeShop.Web.Services;

namespace ShoeShop.Web.Pages;

[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class CartModel(ProductRepository products, LookupRepository lookups) : ShopPage
{
    protected override bool AllowAnonymous => true;
    public CartPanel? Basket { get; private set; }

    public IActionResult OnGet()
    {
        TryDb(() =>
        {
            var lines = Cart.LoadLines(HttpContext.Session, products);
            var points = Account.CanOrder && lines.Count > 0 ? lookups.PickupPoints() : [];
            Basket = new CartPanel(lines, points, Account.CanOrder,
                Account.CanOrder && lines.Count > 0 ? Cart.CheckoutKey(HttpContext.Session) : Guid.Empty);
        }, redirecting: false);
        return Page();
    }
}
