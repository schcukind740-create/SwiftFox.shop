using Microsoft.AspNetCore.Mvc;
using ShoeShop.Web.Data;
using ShoeShop.Web.Models;

namespace ShoeShop.Web.Pages;

[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class IndexModel(ProductRepository products) : ShopPage
{
    protected override bool AllowAnonymous => true;
    public IReadOnlyList<Product> Selection { get; private set; } = [];
    public Product? Featured { get; private set; }

    public IActionResult OnGet()
    {
        TryDb(() =>
        {
            Selection = products.Search(null, 0, null).Take(4).ToList();
            Featured = products.GetByArticle("DM0032-601");
        }, redirecting: false);
        return Page();
    }
}
