using Microsoft.AspNetCore.Mvc;
using ShoeShop.Web.Data;
using ShoeShop.Web.Services;

namespace ShoeShop.Web.Pages;

[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class ProductModel(ProductRepository products) : ShopPage
{
    protected override bool AllowAnonymous => true;
    public ProductPanel? Product { get; private set; }

    public IActionResult OnGet(int id)
    {
        var loaded = TryDb(() =>
        {
            var item = products.GetById(id);
            if (item is not null)
                Product = new ProductPanel(item, Cart.Get(HttpContext.Session).Where(line => line.ProductId == item.Id).Sum(line => line.Quantity));
        }, redirecting: false);
        return loaded && Product is null ? NotFound() : Page();
    }
}
