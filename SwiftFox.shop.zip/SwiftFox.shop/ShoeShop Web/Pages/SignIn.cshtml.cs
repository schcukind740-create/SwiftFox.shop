using Microsoft.AspNetCore.Mvc;

namespace ShoeShop.Web.Pages;

[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class SignInModel : ShopPage
{
    protected override bool AllowAnonymous => true;
    public string? Next { get; private set; }

    public IActionResult OnGet(string? next)
    {
        Next = next is "checkout" or "orders" or "workspace" ? next : null;
        return Account.IsSignedIn ? RedirectToPage("/Profile") : Page();
    }
}
