namespace ShoeShop.Web.Pages;

public abstract class StaffPage : ShopPage
{
    protected override string[] AllowedRoles => [Services.Account.RoleManager, Services.Account.RoleAdmin];
    protected override string SignInNext => "workspace";
}
