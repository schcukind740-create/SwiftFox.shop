using Microsoft.AspNetCore.Mvc;
using ShoeShop.Web.Data;

namespace ShoeShop.Web.Pages;

[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class OrderModel(OrderRepository orders, LookupRepository lookups, ProductRepository products) : StaffPage
{
    public OrderPanel? Editor { get; private set; }

    public IActionResult OnGet(int id = 0)
    {
        var loaded = TryDb(() =>
        {
            var order = id > 0 ? orders.Get(id) : null;
            if (id > 0 && order is null) return;
            Editor = new OrderPanel(order, id > 0 ? [] : lookups.Clients(),
                lookups.PickupPoints(), lookups.Statuses(), products.GetAll());
        }, redirecting: false);
        return loaded && Editor is null ? NotFound() : Page();
    }
}
