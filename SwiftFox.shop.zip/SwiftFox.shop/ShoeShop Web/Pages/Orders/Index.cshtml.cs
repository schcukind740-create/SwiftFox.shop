using Microsoft.AspNetCore.Mvc;
using ShoeShop.Web.Data;

namespace ShoeShop.Web.Pages;

[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class OrdersModel(OrderRepository orders, LookupRepository lookups) : StaffPage
{
    public OrdersPanel? Register { get; private set; }

    public void OnGet(int status = 0) =>
        TryDb(() => Register = new OrdersPanel(orders.List(status), lookups.Statuses(), status), redirecting: false);
}
