using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using ShoeShop.Web.Data;
using ShoeShop.Web.Models;
using ShoeShop.Web.Services;

namespace ShoeShop.Web.Pages;

public class WorkflowModel(ProductRepository products, OrderRepository orders, UserRepository users) : ShopPage
{
    protected override bool AllowAnonymous => true;

    public IActionResult OnGet() => RedirectToPage("/Index");

    public IActionResult OnPostLogin(string? login, string? next)
    {
        var signIn = Url.Page("/SignIn", values: new { next })!;
        if (string.IsNullOrWhiteSpace(login) || login.Length > 100)
            return ErrorResult("Введите логин.", signIn);

        return Write(signIn, () =>
        {
            var user = users.FindByLogin(login) ?? throw new InvalidOperationException("Пользователь с таким логином не найден.");
            SignInWithBasket(user);
            if (next == "checkout") return RedirectToPage("/Checkout");
            if (user.Role is Services.Account.RoleAdmin or Services.Account.RoleManager)
            {
                if (next == "orders") return RedirectToPage("/Orders/Index");
                if (next == "workspace") return RedirectToPage("/Workspace/Dashboard");
            }
            return RedirectToPage("/Profile");
        });
    }

    public IActionResult OnPostRegister(string? login, string? firstName, string? lastName, string? patronymic, string? next)
    {
        var register = Url.Page("/Register", values: new { next })!;
        if (Account.IsSignedIn) return RedirectToPage("/Profile");
        if (string.IsNullOrWhiteSpace(login) || login.Length is < 3 or > 40 ||
            !login.All(c => char.IsAsciiLetterOrDigit(c) || c is '.' or '_' or '-') ||
            string.IsNullOrWhiteSpace(firstName) || firstName.Length > 80 ||
            string.IsNullOrWhiteSpace(lastName) || lastName.Length > 80 || patronymic?.Length > 80)
            return ErrorResult("Укажите имя, фамилию и логин из 3–40 латинских букв, цифр, точек, дефисов или подчёркиваний.", register);

        return Write(register, () =>
        {
            var user = users.Register(login.Trim(), firstName.Trim(), lastName.Trim(),
                string.IsNullOrWhiteSpace(patronymic) ? null : patronymic.Trim());
            SignInWithBasket(user);
            return next == "checkout" ? RedirectToPage("/Checkout") : RedirectToPage("/Profile");
        });
    }

    private void SignInWithBasket(SignedInUser user)
    {
        var basket = Cart.Get(HttpContext.Session);
        Account.SignIn(HttpContext.Session, user);
        foreach (var item in basket)
            Cart.Set(HttpContext.Session, item.ProductId, item.Size, item.Quantity);
    }

    public IActionResult OnPostLogout()
    {
        Account.SignOut(HttpContext.Session);
        Notify("Вы вышли из аккаунта.");
        return RedirectToPage("/Index");
    }

    public IActionResult OnPostAdd(int productId, int size, string? quantity) =>
        Write(Url.Page("/Product", values: new { id = productId })!, () =>
        {
            var qty = Quantity(quantity, 1);
            var product = RequiredProduct(productId);
            var existing = Cart.Quantity(HttpContext.Session, productId, size);
            var stock = product.StockFor(size);
            if (size is < 35 or > 49) throw new InvalidOperationException("Выберите размер обуви.");
            if (qty > stock - existing)
                throw new InvalidOperationException($"Размер EU {size}: доступно {stock}, в корзине уже {existing}.");
            Cart.Set(HttpContext.Session, productId, size, existing + qty);
            Notify($"Товар «{product.Name}» добавлен в корзину.");
            return RedirectToPage("/Cart");
        });

    public IActionResult OnPostCartQuantity(int productId, int size, string? quantity, bool remove = false) =>
        Write(Url.Page("/Cart")!, () =>
        {
            var qty = remove ? 0 : Quantity(quantity);
            if (Cart.Quantity(HttpContext.Session, productId, size) == 0)
                throw new InvalidOperationException("Этой позиции уже нет в корзине.");
            if (qty > 0 && qty > RequiredProduct(productId).StockFor(size))
                throw new InvalidOperationException("На складе недостаточно пар.");
            Cart.Set(HttpContext.Session, productId, size, qty);
            Notify(qty == 0 ? "Позиция удалена." : "Количество обновлено.");
            return RedirectToPage("/Cart");
        });

    public IActionResult OnPostCheckout(int pointId, Guid checkoutKey, string? payment, string? demoResult)
    {
        if (!Account.CanOrder) return RedirectToPage("/SignIn", new { next = "checkout" });
        var cartUrl = Url.Page("/Checkout")!;
        if (pointId <= 0 || checkoutKey == Guid.Empty || payment is not ("pickup" or "demo"))
            return ErrorResult("Выберите пункт выдачи и способ оплаты.", cartUrl);
        if (payment == "demo" && demoResult != "approved")
            return ErrorResult("Пройдите проверку тестовой карты или выберите оплату при получении.", cartUrl);

        return Write(cartUrl, () =>
        {
            IReadOnlyList<CartLine> lines = Cart.CheckoutKey(HttpContext.Session) == checkoutKey
                ? Cart.LoadLines(HttpContext.Session, products) : [];
            var result = orders.CreateFromCart(Account.UserId, pointId, lines, checkoutKey, payment);
            if (!result.Existing)
                Cart.Clear(HttpContext.Session);
            TempData["OrderNumber"] = result.OrderId;
            TempData["PickupCode"] = result.Code;
            return RedirectToPage("/Cart");
        });
    }

    public IActionResult OnPostCreateOrder(int userId, int pointId, int statusId, DateOnly orderDate,
        DateOnly deliveryDate, string? variant, string? quantity) =>
        StaffWrite(0, () =>
        {
            CheckOrderFields(pointId, statusId, orderDate, deliveryDate);
            if (userId <= 0) throw new InvalidOperationException("Выберите покупателя.");
            var (productId, size) = Variant(variant);
            var qty = Quantity(quantity, 1);
            var product = RequiredSize(productId, size);
            var id = orders.Create(userId, pointId, statusId, orderDate, deliveryDate, productId, size, qty, product.FinalPrice);
            Notify($"Заказ №{id} создан.");
            return RedirectToPage("/Orders/Details", new { id });
        });

    public IActionResult OnPostEditOrder(int orderId, int pointId, int statusId, DateOnly orderDate, DateOnly deliveryDate) =>
        StaffWrite(orderId, () =>
        {
            CheckOrderFields(pointId, statusId, orderDate, deliveryDate);
            orders.Update(orderId, statusId, orderDate, deliveryDate, pointId);
            Notify("Заказ сохранён.");
            return RedirectToPage("/Orders/Details", new { id = orderId });
        });

    public IActionResult OnPostOrderQuantity(int orderId, int productId, int size, string? quantity, bool remove = false) =>
        StaffWrite(orderId, () =>
        {
            orders.SetQuantity(orderId, productId, size, remove ? 0 : Quantity(quantity));
            Notify("Количество обновлено.");
            return RedirectToPage("/Orders/Details", new { id = orderId });
        });

    public IActionResult OnPostOrderAdd(int orderId, string? variant, string? quantity) =>
        StaffWrite(orderId, () =>
        {
            var (productId, size) = Variant(variant);
            var qty = Quantity(quantity, 1);
            var product = RequiredSize(productId, size);
            orders.AddLine(orderId, productId, size, qty, product.FinalPrice);
            Notify("Позиция добавлена.");
            return RedirectToPage("/Orders/Details", new { id = orderId });
        });

    public IActionResult OnPostDeleteOrder(int orderId) => StaffWrite(orderId, () =>
    {
        orders.Delete(orderId);
        Notify("Заказ удалён.");
        return RedirectToPage("/Orders/Index");
    });

    private static (int ProductId, int Size) Variant(string? variant)
    {
        var parts = variant?.Split(':');
        if (parts is not { Length: 2 } || !int.TryParse(parts[0], out var productId) ||
            !int.TryParse(parts[1], out var size) || productId <= 0 || size is < 35 or > 49)
            throw new InvalidOperationException("Выберите модель и размер.");
        return (productId, size);
    }

    private Product RequiredSize(int productId, int size)
    {
        var product = RequiredProduct(productId);
        if (!product.Sizes.Any(item => item.Eu == size))
            throw new InvalidOperationException("Выберите размер этой модели.");
        return product;
    }

    private Product RequiredProduct(int id) =>
        products.GetById(id) ?? throw new InvalidOperationException("Товар не найден.");

    private IActionResult StaffWrite(int orderId, Func<IActionResult> action)
    {
        if (!Account.IsSignedIn) return RedirectToPage("/SignIn", new { next = "orders" });
        if (!Account.IsStaff) return StatusCode(403);
        var url = orderId > 0
            ? Url.Page("/Orders/Details", values: new { id = orderId })!
            : Url.Page("/Orders/Details")!;
        return Write(url, action);
    }

    private IActionResult Write(string failureUrl, Func<IActionResult> action)
    {
        if (!ModelState.IsValid) return ErrorResult("Проверьте значения полей.", failureUrl);
        try { return action(); }
        catch (Npgsql.NpgsqlException ex) { return ErrorResult(DbErrors.Describe(ex), failureUrl); }
        catch (InvalidOperationException ex) { return ErrorResult(DbErrors.Describe(ex), failureUrl); }
    }

    private IActionResult ErrorResult(string message, string next)
    {
        Fail(message);
        return LocalRedirect(next);
    }

    private static int Quantity(string? input, int min = 0)
    {
        if (input is null || !input.All(char.IsAsciiDigit) ||
            !int.TryParse(input, NumberStyles.None, CultureInfo.InvariantCulture, out var number) ||
            number < min || number > 999)
            throw new InvalidOperationException($"Введите целое количество от {min} до 999.");
        return number;
    }

    private static void CheckOrderFields(int pointId, int statusId, DateOnly ordered, DateOnly delivery)
    {
        if (pointId <= 0 || statusId <= 0 || ordered == default || delivery < ordered)
            throw new InvalidOperationException("Проверьте пункт выдачи, статус и даты заказа.");
    }
}
