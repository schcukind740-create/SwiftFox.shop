using Microsoft.AspNetCore.Mvc;

namespace ShoeShop.Web.Pages;

[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class RegisterModel : ShopPage
{
    protected override bool AllowAnonymous => true;
    public string? Next { get; private set; }

    public IActionResult OnGet(string? next)
    {
        Next = next == "checkout" ? next : null;
        return Account.IsSignedIn ? RedirectToPage("/Profile") : Page();
    }
}
