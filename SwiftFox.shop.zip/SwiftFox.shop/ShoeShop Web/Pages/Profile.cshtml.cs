using Microsoft.AspNetCore.Mvc;
using ShoeShop.Web.Data;
using ShoeShop.Web.Models;

namespace ShoeShop.Web.Pages;

[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class ProfileModel(OrderRepository orders) : ShopPage
{
    public List<OrderRow> History { get; private set; } = [];
    public OrderDetails? Detail { get; private set; }

    public IActionResult OnGet(int? order)
    {
        var loaded = TryDb(() =>
        {
            History = orders.List(0, Account.UserId);
            if (order is int id && History.Any(item => item.Id == id))
                Detail = orders.Get(id);
        }, redirecting: false);
        return loaded && order.HasValue && Detail is null ? NotFound() : Page();
    }
}
