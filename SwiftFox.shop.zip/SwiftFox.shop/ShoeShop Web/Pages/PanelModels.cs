using ShoeShop.Web.Models;

namespace ShoeShop.Web.Pages;

public record ProductPanel(Product Product, int InCart);
public record CartPanel(IReadOnlyList<CartLine> Lines, IReadOnlyList<PickupPoint> Points, bool CanOrder, Guid CheckoutKey);
public record OrdersPanel(IReadOnlyList<OrderRow> Rows, IReadOnlyList<OrderStatus> Statuses, int SelectedStatus);
public record OrderPanel(OrderDetails? Order, IReadOnlyList<Client> Clients, IReadOnlyList<PickupPoint> Points,
    IReadOnlyList<OrderStatus> Statuses, IReadOnlyList<Product> Products);
