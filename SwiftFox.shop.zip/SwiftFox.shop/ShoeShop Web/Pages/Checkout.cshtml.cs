using Microsoft.AspNetCore.Mvc;
using ShoeShop.Web.Data;
using ShoeShop.Web.Services;

namespace ShoeShop.Web.Pages;

[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class CheckoutModel(ProductRepository products, LookupRepository lookups) : ShopPage
{
    protected override string SignInNext => "checkout";
    public CartPanel? Basket { get; private set; }

    public IActionResult OnGet()
    {
        var loaded = TryDb(() =>
        {
            var lines = Cart.LoadLines(HttpContext.Session, products);
            Basket = new CartPanel(lines, lookups.PickupPoints(), Account.CanOrder, Cart.CheckoutKey(HttpContext.Session));
        }, redirecting: false);
        return loaded && Basket?.Lines.Count == 0 ? RedirectToPage("/Cart") : Page();
    }
}
