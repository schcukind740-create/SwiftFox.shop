using Npgsql;

namespace ShoeShop.Web.Data;

/// <summary>
/// Единая точка подключения к PostgreSQL. Строка подключения берётся
/// из appsettings.json (раздел ConnectionStrings:ShoeShop).
/// </summary>
public sealed class Database : IDisposable
{
    private readonly NpgsqlDataSource _dataSource;

    public Database(IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("ShoeShop")
            ?? throw new InvalidOperationException("В appsettings.json не задана строка подключения ShoeShop.");
        _dataSource = NpgsqlDataSource.Create(connectionString);
    }

    public NpgsqlConnection Open() => _dataSource.OpenConnection();

    public void Dispose() => _dataSource.Dispose();
}
