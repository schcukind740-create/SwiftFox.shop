using Npgsql;
using ShoeShop.Web.Models;

namespace ShoeShop.Web.Data;

/// <summary>
/// Работа с заказами. Все изменения выполняются в транзакции вместе с пересчётом остатков:
/// товар списывается со склада, пока заказ не отменён, и возвращается при отмене,
/// уменьшении количества или удалении незавершённого заказа.
/// </summary>
public class OrderRepository
{
    public const string StatusNew = "Новый";
    public const string StatusIssued = "Выдан";
    public const string StatusCancelled = "Отменён";

    private readonly Database _db;

    public OrderRepository(Database db) => _db = db;

    public List<OrderRow> List(int statusId, int userId = 0)
    {
        const string sql = """
            SELECT o.order_id, o.order_date, o.delivery_date,
                   concat_ws(' ', u.last_name, u.first_name, u.patronymic),
                   pp.address, st.name, o.pickup_code,
                   coalesce(sum(oi.quantity), 0), coalesce(sum(oi.quantity * oi.price), 0)
            FROM orders o
            JOIN app_user u      ON u.user_id = o.user_id
            JOIN pickup_point pp ON pp.point_id = o.point_id
            JOIN order_status st ON st.status_id = o.status_id
            LEFT JOIN order_item oi ON oi.order_id = o.order_id
            WHERE (@status = 0 OR o.status_id = @status) AND (@user = 0 OR o.user_id = @user)
            GROUP BY o.order_id, u.user_id, pp.address, st.name
            ORDER BY o.order_date DESC, o.order_id DESC
            """;

        using var conn = _db.Open();
        using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("status", statusId);
        cmd.Parameters.AddWithValue("user", userId);

        var list = new List<OrderRow>();
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            list.Add(new OrderRow
            {
                Id = r.GetInt32(0),
                OrderDate = r.GetFieldValue<DateOnly>(1),
                DeliveryDate = r.GetFieldValue<DateOnly>(2),
                Client = r.GetString(3),
                Address = r.GetString(4),
                Status = r.GetString(5),
                PickupCode = r.GetInt32(6),
                Pairs = Convert.ToInt32(r.GetValue(7)),
                Total = r.GetDecimal(8)
            });
        }
        return list;
    }

    public OrderDetails? Get(int id)
    {
        using var conn = _db.Open();

        OrderDetails order;
        using (var cmd = new NpgsqlCommand("""
            SELECT o.order_id, o.user_id, concat_ws(' ', u.last_name, u.first_name, u.patronymic),
                   o.point_id, o.status_id, st.name, o.order_date, o.delivery_date, o.pickup_code, o.payment_method
            FROM orders o
            JOIN app_user u      ON u.user_id = o.user_id
            JOIN order_status st ON st.status_id = o.status_id
            WHERE o.order_id = @id
            """, conn))
        {
            cmd.Parameters.AddWithValue("id", id);
            using var r = cmd.ExecuteReader();
            if (!r.Read()) return null;
            order = new OrderDetails
            {
                Id = r.GetInt32(0),
                UserId = r.GetInt32(1),
                Client = r.GetString(2),
                PointId = r.GetInt32(3),
                StatusId = r.GetInt32(4),
                Status = r.GetString(5),
                OrderDate = r.GetFieldValue<DateOnly>(6),
                DeliveryDate = r.GetFieldValue<DateOnly>(7),
                PickupCode = r.GetInt32(8),
                PaymentMethod = r.GetString(9)
            };
        }

        using (var cmd = new NpgsqlCommand("""
            SELECT p.product_id, p.article, p.name, oi.quantity, oi.price, oi.eu_size
            FROM order_item oi
            JOIN product p ON p.product_id = oi.product_id
            WHERE oi.order_id = @id
            ORDER BY p.name, oi.eu_size
            """, conn))
        {
            cmd.Parameters.AddWithValue("id", id);
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                order.Lines.Add(new OrderLine
                {
                    ProductId = r.GetInt32(0),
                    Article = r.GetString(1),
                    Name = r.GetString(2),
                    Quantity = r.GetInt32(3),
                    Price = r.GetDecimal(4),
                    Size = r.GetInt32(5)
                });
            }
        }

        return order;
    }

    /// <summary>Оформление заказа из корзины. Возвращает номер заказа и код получения.</summary>
    public (int OrderId, int Code, bool Existing) CreateFromCart(int userId, int pointId, IReadOnlyList<CartLine> lines, Guid checkoutKey, string payment)
    {
        using var conn = _db.Open();
        using var tx = conn.BeginTransaction();

        var prior = PreviousCheckout(conn, tx, userId, checkoutKey);
        if (prior is { } previous) return (previous.OrderId, previous.Code, true);
        if (lines.Count == 0) throw new InvalidOperationException("Корзина пуста или изменилась. Откройте её повторно.");

        EnsureActiveBuyer(conn, tx, userId);
        var today = DateOnly.FromDateTime(DateTime.Today);
        var code = Random.Shared.Next(100, 1000);
        using var cmd = new NpgsqlCommand("""
            INSERT INTO orders (user_id, point_id, status_id, order_date, delivery_date, pickup_code, checkout_key, payment_method)
            VALUES (@user, @point, @status, @today, @delivery, @code, @key, @payment)
            ON CONFLICT (checkout_key) DO NOTHING
            RETURNING order_id
            """, conn, tx);
        cmd.Parameters.AddWithValue("user", userId);
        cmd.Parameters.AddWithValue("point", pointId);
        cmd.Parameters.AddWithValue("status", StatusId(conn, tx, StatusNew));
        cmd.Parameters.AddWithValue("today", today);
        cmd.Parameters.AddWithValue("delivery", today.AddDays(3));
        cmd.Parameters.AddWithValue("code", code);
        cmd.Parameters.AddWithValue("key", checkoutKey);
        cmd.Parameters.AddWithValue("payment", payment);

        if (cmd.ExecuteScalar() is not int orderId)
        {
            var existing = PreviousCheckout(conn, tx, userId, checkoutKey)
                ?? throw new InvalidOperationException("Откройте корзину повторно и оформите заказ.");
            return (existing.OrderId, existing.Code, true);
        }

        SetStockReason(conn, tx, $"Заказ №{orderId}");
        foreach (var line in lines.OrderBy(line => line.Product.Id).ThenBy(line => line.Size))
        {
            TakeStock(conn, tx, line.Product.Id, line.Size, line.Quantity);
            InsertLine(conn, tx, orderId, line.Product.Id, line.Size, line.Quantity, line.Product.FinalPrice);
        }

        tx.Commit();
        return (orderId, code, false);
    }

    private static (int OrderId, int Code)? PreviousCheckout(NpgsqlConnection conn, NpgsqlTransaction tx,
        int userId, Guid checkoutKey)
    {
        using var cmd = new NpgsqlCommand("""
            SELECT order_id, pickup_code FROM orders WHERE checkout_key = @key AND user_id = @user
            """, conn, tx);
        cmd.Parameters.AddWithValue("key", checkoutKey);
        cmd.Parameters.AddWithValue("user", userId);
        using var reader = cmd.ExecuteReader();
        return reader.Read() ? (reader.GetInt32(0), reader.GetInt32(1)) : null;
    }

    /// <summary>Создание заказа сотрудником (первая позиция обязательна, остальные добавляются потом).</summary>
    public int Create(int userId, int pointId, int statusId, DateOnly orderDate, DateOnly deliveryDate,
                      int productId, int size, int quantity, decimal price)
    {
        using var conn = _db.Open();
        using var tx = conn.BeginTransaction();

        EnsureActiveBuyer(conn, tx, userId);
        var orderId = InsertOrder(conn, tx, userId, pointId, statusId, orderDate, deliveryDate,
                                  Random.Shared.Next(100, 1000));

        SetStockReason(conn, tx, $"Заказ №{orderId}");
        if (HoldsStock(StatusName(conn, tx, statusId)))
            TakeStock(conn, tx, productId, size, quantity);
        InsertLine(conn, tx, orderId, productId, size, quantity, price);

        tx.Commit();
        return orderId;
    }

    /// <summary>Смена статуса и данных заказа сотрудником.</summary>
    public void Update(int orderId, int statusId, DateOnly? orderDate, DateOnly? deliveryDate, int? pointId)
    {
        using var conn = _db.Open();
        using var tx = conn.BeginTransaction();

        var oldStatus = CurrentStatus(conn, tx, orderId);
        var newStatus = StatusName(conn, tx, statusId);
        SetStockReason(conn, tx, $"Заказ №{orderId} · {newStatus}");

        // При отмене товар возвращается на склад, при возврате из отмены списывается снова
        if (HoldsStock(oldStatus) != HoldsStock(newStatus))
        {
            foreach (var (productId, size, quantity) in Lines(conn, tx, orderId))
            {
                if (HoldsStock(newStatus)) TakeStock(conn, tx, productId, size, quantity);
                else ReturnStock(conn, tx, productId, size, quantity);
            }
        }

        using var cmd = new NpgsqlCommand("""
            UPDATE orders
            SET status_id     = @status,
                order_date    = coalesce(@orderDate, order_date),
                delivery_date = coalesce(@deliveryDate, delivery_date),
                point_id      = coalesce(@point, point_id)
            WHERE order_id = @id
            """, conn, tx);
        cmd.Parameters.AddWithValue("status", statusId);
        cmd.Parameters.Add(new NpgsqlParameter<DateOnly?>("orderDate", orderDate));
        cmd.Parameters.Add(new NpgsqlParameter<DateOnly?>("deliveryDate", deliveryDate));
        cmd.Parameters.Add(new NpgsqlParameter<int?>("point", pointId));
        cmd.Parameters.AddWithValue("id", orderId);
        cmd.ExecuteNonQuery();

        tx.Commit();
    }

    /// <summary>Изменение количества в позиции. Количество 0 удаляет позицию.</summary>
    public void SetQuantity(int orderId, int productId, int size, int quantity)
    {
        using var conn = _db.Open();
        using var tx = conn.BeginTransaction();

        var status = CurrentStatus(conn, tx, orderId);
        SetStockReason(conn, tx, $"Заказ №{orderId} · изменение");
        var lines = Lines(conn, tx, orderId);
        var old = lines.FirstOrDefault(l => l.ProductId == productId && l.Size == size);
        if (old.ProductId == 0)
            throw new InvalidOperationException("Такой позиции в заказе нет.");
        if (quantity == 0 && lines.Count == 1)
            throw new InvalidOperationException("В заказе должна остаться хотя бы одна позиция. Чтобы освободить остатки, отмените заказ.");

        if (HoldsStock(status))
        {
            var diff = quantity - old.Quantity;
            if (diff > 0) TakeStock(conn, tx, productId, size, diff);
            if (diff < 0) ReturnStock(conn, tx, productId, size, -diff);
        }

        var sql = quantity == 0
            ? "DELETE FROM order_item WHERE order_id = @order AND product_id = @product AND eu_size = @size"
            : "UPDATE order_item SET quantity = @qty WHERE order_id = @order AND product_id = @product AND eu_size = @size";
        using var cmd = new NpgsqlCommand(sql, conn, tx);
        cmd.Parameters.AddWithValue("order", orderId);
        cmd.Parameters.AddWithValue("product", productId);
        cmd.Parameters.AddWithValue("size", size);
        cmd.Parameters.AddWithValue("qty", quantity);
        cmd.ExecuteNonQuery();

        tx.Commit();
    }

    public void AddLine(int orderId, int productId, int size, int quantity, decimal price)
    {
        using var conn = _db.Open();
        using var tx = conn.BeginTransaction();

        var status = CurrentStatus(conn, tx, orderId);
        SetStockReason(conn, tx, $"Заказ №{orderId} · изменение");
        if (Lines(conn, tx, orderId).Any(l => l.ProductId == productId && l.Size == size))
            throw new InvalidOperationException("Этот товар уже есть в заказе, измените его количество.");

        if (HoldsStock(status))
            TakeStock(conn, tx, productId, size, quantity);
        InsertLine(conn, tx, orderId, productId, size, quantity, price);

        tx.Commit();
    }

    public void Delete(int orderId)
    {
        using var conn = _db.Open();
        using var tx = conn.BeginTransaction();

        // Выданный товар уже у покупателя, отменённый уже вернулся на склад
        var status = CurrentStatus(conn, tx, orderId);
        SetStockReason(conn, tx, $"Заказ №{orderId} · удаление");
        if (status != StatusIssued && status != StatusCancelled)
        {
            foreach (var (productId, size, quantity) in Lines(conn, tx, orderId))
                ReturnStock(conn, tx, productId, size, quantity);
        }

        using var cmd = new NpgsqlCommand("DELETE FROM orders WHERE order_id = @id", conn, tx);
        cmd.Parameters.AddWithValue("id", orderId);
        cmd.ExecuteNonQuery();

        tx.Commit();
    }

    private static void EnsureActiveBuyer(NpgsqlConnection conn, NpgsqlTransaction tx, int userId)
    {
        using var command = new NpgsqlCommand("SELECT user_id FROM app_user WHERE user_id=@id AND active FOR SHARE", conn, tx);
        command.Parameters.AddWithValue("id", userId);
        if (command.ExecuteScalar() is null) throw new InvalidOperationException("Учётная запись покупателя недоступна.");
    }

    private static bool HoldsStock(string status) => status != StatusCancelled;

    private static int InsertOrder(NpgsqlConnection conn, NpgsqlTransaction tx, int userId, int pointId,
                                   int statusId, DateOnly orderDate, DateOnly deliveryDate, int code)
    {
        using var cmd = new NpgsqlCommand("""
            INSERT INTO orders (user_id, point_id, status_id, order_date, delivery_date, pickup_code)
            VALUES (@user, @point, @status, @orderDate, @deliveryDate, @code)
            RETURNING order_id
            """, conn, tx);
        cmd.Parameters.AddWithValue("user", userId);
        cmd.Parameters.AddWithValue("point", pointId);
        cmd.Parameters.AddWithValue("status", statusId);
        cmd.Parameters.AddWithValue("orderDate", orderDate);
        cmd.Parameters.AddWithValue("deliveryDate", deliveryDate);
        cmd.Parameters.AddWithValue("code", code);
        return (int)cmd.ExecuteScalar()!;
    }

    private static void InsertLine(NpgsqlConnection conn, NpgsqlTransaction tx, int orderId,
                                   int productId, int size, int quantity, decimal price)
    {
        using var cmd = new NpgsqlCommand("""
            INSERT INTO order_item (order_id, product_id, eu_size, quantity, price)
            VALUES (@order, @product, @size, @qty, @price)
            """, conn, tx);
        cmd.Parameters.AddWithValue("order", orderId);
        cmd.Parameters.AddWithValue("product", productId);
        cmd.Parameters.AddWithValue("size", size);
        cmd.Parameters.AddWithValue("qty", quantity);
        cmd.Parameters.AddWithValue("price", price);
        cmd.ExecuteNonQuery();
    }

    private static void TakeStock(NpgsqlConnection conn, NpgsqlTransaction tx, int productId, int size, int quantity)
    {
        using var cmd = new NpgsqlCommand("""
            UPDATE product_size SET stock = stock - @qty
            WHERE product_id = @id AND eu_size = @size AND stock >= @qty
            """, conn, tx);
        cmd.Parameters.AddWithValue("qty", quantity);
        cmd.Parameters.AddWithValue("id", productId);
        cmd.Parameters.AddWithValue("size", size);

        if (cmd.ExecuteNonQuery() == 0)
        {
            using var info = new NpgsqlCommand("SELECT name, coalesce(s.stock,0) FROM product p LEFT JOIN product_size s ON s.product_id=p.product_id AND s.eu_size=@size WHERE p.product_id=@id", conn, tx);
            info.Parameters.AddWithValue("id", productId);
            info.Parameters.AddWithValue("size", size);
            using var r = info.ExecuteReader();
            var text = r.Read()
                ? $"Недостаточно товара «{r.GetString(0)}» размера EU {size}: осталось {r.GetInt32(1)}, нужно {quantity}."
                : "Товар не найден.";
            throw new InvalidOperationException(text);
        }
    }

    private static void ReturnStock(NpgsqlConnection conn, NpgsqlTransaction tx, int productId, int size, int quantity)
    {
        using var cmd = new NpgsqlCommand("UPDATE product_size SET stock = stock + @qty WHERE product_id = @id AND eu_size = @size", conn, tx);
        cmd.Parameters.AddWithValue("qty", quantity);
        cmd.Parameters.AddWithValue("id", productId);
        cmd.Parameters.AddWithValue("size", size);
        cmd.ExecuteNonQuery();
    }

    private static List<(int ProductId, int Size, int Quantity)> Lines(NpgsqlConnection conn, NpgsqlTransaction tx, int orderId)
    {
        using var cmd = new NpgsqlCommand(
            "SELECT product_id, eu_size, quantity FROM order_item WHERE order_id = @id ORDER BY product_id, eu_size FOR UPDATE", conn, tx);
        cmd.Parameters.AddWithValue("id", orderId);
        var list = new List<(int, int, int)>();
        using var r = cmd.ExecuteReader();
        while (r.Read()) list.Add((r.GetInt32(0), r.GetInt32(1), r.GetInt32(2)));
        return list;
    }

    private static void SetStockReason(NpgsqlConnection conn, NpgsqlTransaction tx, string value)
    {
        using var cmd = new NpgsqlCommand("SELECT set_config('swiftfox.stock_reason', @reason, true)", conn, tx);
        cmd.Parameters.AddWithValue("reason", value);
        cmd.ExecuteNonQuery();
    }

    private static string CurrentStatus(NpgsqlConnection conn, NpgsqlTransaction tx, int orderId)
    {
        using var cmd = new NpgsqlCommand("""
            SELECT st.name FROM orders o
            JOIN order_status st ON st.status_id = o.status_id
            WHERE o.order_id = @id
            FOR UPDATE OF o
            """, conn, tx);
        cmd.Parameters.AddWithValue("id", orderId);
        return cmd.ExecuteScalar() as string
               ?? throw new InvalidOperationException($"Заказ №{orderId} не найден.");
    }

    private static string StatusName(NpgsqlConnection conn, NpgsqlTransaction tx, int statusId)
    {
        using var cmd = new NpgsqlCommand("SELECT name FROM order_status WHERE status_id = @id", conn, tx);
        cmd.Parameters.AddWithValue("id", statusId);
        return cmd.ExecuteScalar() as string
               ?? throw new InvalidOperationException("Выбран несуществующий статус.");
    }

    private static int StatusId(NpgsqlConnection conn, NpgsqlTransaction tx, string name)
    {
        using var cmd = new NpgsqlCommand("SELECT status_id FROM order_status WHERE name = @name", conn, tx);
        cmd.Parameters.AddWithValue("name", name);
        return (int)(cmd.ExecuteScalar()
               ?? throw new InvalidOperationException($"В справочнике нет статуса «{name}»."));
    }
}
