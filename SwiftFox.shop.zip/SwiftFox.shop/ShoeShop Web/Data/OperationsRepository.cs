using Npgsql;
using NpgsqlTypes;
using ShoeShop.Web.Models;

namespace ShoeShop.Web.Data;

public class OperationsRepository(Database db)
{
    public List<ReferenceItem> Roles() => References("SELECT role_id, name FROM role ORDER BY role_id");
    public List<ReferenceItem> Brands() => References("SELECT manufacturer_id, name FROM manufacturer ORDER BY name");
    public List<ReferenceItem> Suppliers() => References("SELECT supplier_id, name FROM supplier ORDER BY name");

    public List<Member> Members() => Read("""
        SELECT u.user_id, u.login, u.first_name, u.last_name, u.patronymic, u.role_id, r.name, u.active
        FROM app_user u JOIN role r USING (role_id)
        ORDER BY u.active DESC, u.last_name, u.first_name
        """, row => new Member(row.GetInt32(0), row.GetString(1), row.GetString(2), row.GetString(3),
            row.IsDBNull(4) ? null : row.GetString(4), row.GetInt32(5), row.GetString(6), row.GetBoolean(7)));

    public void SaveMember(int id, string login, string firstName, string lastName, string? patronymic, int roleId, int actor)
    {
        using var connection = db.Open();
        using var tx = connection.BeginTransaction();
        LockMemberEdits(connection, tx, actor);
        using var command = new NpgsqlCommand(id == 0 ? """
            INSERT INTO app_user (login, first_name, last_name, patronymic, role_id)
            VALUES (lower(@login), @first, @last, @patronymic, @role)
            """ : """
            UPDATE app_user SET login=lower(@login), first_name=@first, last_name=@last,
                patronymic=@patronymic, role_id=@role
            WHERE user_id=@id AND (user_id<>@actor OR role_id=@role)
            """, connection, tx);
        command.Parameters.AddWithValue("id", id);
        command.Parameters.AddWithValue("actor", actor);
        command.Parameters.AddWithValue("login", login);
        command.Parameters.AddWithValue("first", firstName);
        command.Parameters.AddWithValue("last", lastName);
        command.Parameters.AddWithValue("patronymic", NpgsqlDbType.Text, (object?)patronymic ?? DBNull.Value);
        command.Parameters.AddWithValue("role", roleId);
        if (command.ExecuteNonQuery() == 0)
            throw new InvalidOperationException("Пользователь не найден или вы меняете собственную роль.");
        tx.Commit();
    }

    public bool RemoveMember(int id, int actor)
    {
        if (id == actor)
            throw new InvalidOperationException("Нельзя удалить собственную учётную запись.");
        using var connection = db.Open();
        using var tx = connection.BeginTransaction();
        LockMemberEdits(connection, tx, actor);
        using var member = new NpgsqlCommand("SELECT user_id FROM app_user WHERE user_id=@id FOR UPDATE", connection, tx);
        member.Parameters.AddWithValue("id", id);
        if (member.ExecuteScalar() is null)
            throw new InvalidOperationException("Пользователь не найден.");
        using var history = new NpgsqlCommand("SELECT EXISTS(SELECT 1 FROM orders WHERE user_id=@id)", connection, tx);
        history.Parameters.AddWithValue("id", id);
        var hasOrders = (bool)history.ExecuteScalar()!;
        using var command = new NpgsqlCommand(hasOrders
            ? "UPDATE app_user SET active=false WHERE user_id=@id"
            : "DELETE FROM app_user WHERE user_id=@id", connection, tx);
        command.Parameters.AddWithValue("id", id);
        command.ExecuteNonQuery();
        tx.Commit();
        return hasOrders;
    }

    public void RestoreMember(int id, int actor)
    {
        using var connection = db.Open();
        using var tx = connection.BeginTransaction();
        LockMemberEdits(connection, tx, actor);
        using var command = new NpgsqlCommand("UPDATE app_user SET active=true WHERE user_id=@id AND NOT active", connection, tx);
        command.Parameters.AddWithValue("id", id);
        if (command.ExecuteNonQuery() == 0) throw new InvalidOperationException("Запись в архиве не найдена.");
        tx.Commit();
    }

    private static void LockMemberEdits(NpgsqlConnection connection, NpgsqlTransaction tx, int actor)
    {
        using var gate = new NpgsqlCommand("SELECT pg_advisory_xact_lock(56023, 1)", connection, tx);
        gate.ExecuteNonQuery();
        using var verify = new NpgsqlCommand("""
            SELECT 1 FROM app_user u JOIN role r USING (role_id)
            WHERE u.user_id=@actor AND u.active AND r.name='Администратор'
            """, connection, tx);
        verify.Parameters.AddWithValue("actor", actor);
        if (verify.ExecuteScalar() is null)
            throw new InvalidOperationException("Для управления пользователями требуется роль администратора.");
    }

    public int SaveProduct(int id, string article, string name, int category, int brand, int supplier,
        decimal price, string? description, string? photo, int? initialSize, int initialStock)
    {
        using var connection = db.Open();
        using var tx = connection.BeginTransaction();
        using var command = new NpgsqlCommand(id == 0 ? """
            INSERT INTO product (article,name,category_id,manufacturer_id,supplier_id,unit,price,description,photo)
            VALUES (@article,@name,@category,@brand,@supplier,'пара',@price,@description,@photo)
            RETURNING product_id
            """ : """
            UPDATE product SET article=@article, name=@name, category_id=@category, manufacturer_id=@brand,
                supplier_id=@supplier, price=@price, description=@description, photo=coalesce(@photo,photo)
            WHERE product_id=@id
            RETURNING product_id
            """, connection, tx);
        command.Parameters.AddWithValue("id", id);
        command.Parameters.AddWithValue("article", article);
        command.Parameters.AddWithValue("name", name);
        command.Parameters.AddWithValue("category", category);
        command.Parameters.AddWithValue("brand", brand);
        command.Parameters.AddWithValue("supplier", supplier);
        command.Parameters.AddWithValue("price", price);
        command.Parameters.AddWithValue("description", NpgsqlDbType.Text, (object?)description ?? DBNull.Value);
        command.Parameters.AddWithValue("photo", NpgsqlDbType.Text, (object?)photo ?? DBNull.Value);
        var productId = (int?)command.ExecuteScalar() ?? throw new InvalidOperationException("Товар не найден.");
        if (id == 0 && initialSize is int size)
            WriteStock(connection, tx, productId, size, initialStock);
        tx.Commit();
        return productId;
    }

    public void SetStock(int productId, int size, int stock)
    {
        using var connection = db.Open();
        using var tx = connection.BeginTransaction();
        WriteStock(connection, tx, productId, size, stock);
        tx.Commit();
    }

    public List<InventoryMovement> Movements() => Read("""
        SELECT m.changed_at,p.article,p.name,m.eu_size,m.delta,m.stock_after,m.reason
        FROM inventory_movement m JOIN product p USING (product_id)
        ORDER BY m.changed_at DESC, m.movement_id DESC LIMIT 24
        """, row => new InventoryMovement(row.GetDateTime(0), row.GetString(1), row.GetString(2),
            row.GetInt32(3), row.GetInt32(4), row.GetInt32(5), row.GetString(6)));

    public List<DailyOrders> Week() => Read("""
        SELECT day::date, count(o.order_id)::int
        FROM generate_series(current_date-6, current_date, interval '1 day') day
        LEFT JOIN orders o ON o.order_date=day::date
        GROUP BY day ORDER BY day
        """, row => new DailyOrders(row.GetFieldValue<DateOnly>(0), row.GetInt32(1)));

    private static void WriteStock(NpgsqlConnection connection, NpgsqlTransaction tx, int productId, int size, int stock)
    {
        using var command = new NpgsqlCommand("""
            INSERT INTO product_size (product_id,eu_size,stock) VALUES (@id,@size,@stock)
            ON CONFLICT (product_id,eu_size) DO UPDATE SET stock=excluded.stock
            """, connection, tx);
        command.Parameters.AddWithValue("id", productId);
        command.Parameters.AddWithValue("size", size);
        command.Parameters.AddWithValue("stock", stock);
        command.ExecuteNonQuery();
    }

    private List<ReferenceItem> References(string sql) => Read(sql, row => new ReferenceItem(row.GetInt32(0), row.GetString(1)));

    private List<T> Read<T>(string sql, Func<NpgsqlDataReader,T> map)
    {
        using var connection = db.Open();
        using var command = new NpgsqlCommand(sql, connection);
        using var reader = command.ExecuteReader();
        var rows = new List<T>();
        while (reader.Read()) rows.Add(map(reader));
        return rows;
    }
}
