using System.Globalization;
using Npgsql;
using NpgsqlTypes;
using ShoeShop.Web.Models;

namespace ShoeShop.Web.Data;

public class UserRepository(Database db)
{
    public SignedInUser? FindByLogin(string login) => Find("lower(@value) = u.login", login.Trim());
    public SignedInUser? FindById(int id) => Find("u.user_id = @value", id);

    public SignedInUser Register(string login, string firstName, string lastName, string? patronymic)
    {
        using var connection = db.Open();
        using var command = new NpgsqlCommand("""
            INSERT INTO app_user (login, first_name, last_name, patronymic, role_id)
            SELECT lower(@login), @first, @last, @patronymic, role_id FROM role WHERE name='Покупатель'
            RETURNING user_id
            """, connection);
        command.Parameters.AddWithValue("login", login);
        command.Parameters.AddWithValue("first", firstName);
        command.Parameters.AddWithValue("last", lastName);
        command.Parameters.AddWithValue("patronymic", NpgsqlDbType.Text, (object?)patronymic ?? DBNull.Value);
        var id = command.ExecuteScalar() as int?
            ?? throw new InvalidOperationException("Регистрация временно недоступна.");
        return new SignedInUser(id, string.Join(" ", new[] { lastName, firstName, patronymic }.Where(part => part is not null)), "Покупатель", Initials(lastName, firstName));
    }

    private static string Initials(string lastName, string firstName) =>
        (StringInfo.GetNextTextElement(lastName.Trim()) + StringInfo.GetNextTextElement(firstName.Trim())).ToUpperInvariant();

    private SignedInUser? Find<T>(string predicate, T value) where T : notnull
    {
        using var connection = db.Open();
        using var command = new NpgsqlCommand("""
            SELECT u.user_id, concat_ws(' ', u.last_name, u.first_name, u.patronymic), r.name, u.last_name, u.first_name
            FROM app_user u JOIN role r USING (role_id) WHERE u.active AND
            """ + " (" + predicate + ")", connection);
        command.Parameters.AddWithValue("value", value);
        using var reader = command.ExecuteReader();
        return reader.Read() ? new SignedInUser(reader.GetInt32(0), reader.GetString(1), reader.GetString(2), Initials(reader.GetString(3), reader.GetString(4))) : null;
    }
}
