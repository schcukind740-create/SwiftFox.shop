using Npgsql;
using ShoeShop.Web.Models;
using ShoeShop.Web.Services;

namespace ShoeShop.Web.Data;

public class ProductRepository
{
    private readonly Database _db;

    public ProductRepository(Database db) => _db = db;

    // Признак "заказывался в прошлом месяце" считается в самом запросе,
    // границы месяца передаются параметрами @from и @to.
    private const string SelectSql = """
        SELECT p.product_id, p.article, p.name, c.name, m.name, s.name,
               p.unit, p.price, p.description, p.photo,
               ARRAY(SELECT eu_size FROM product_size WHERE product_id=p.product_id ORDER BY eu_size),
               ARRAY(SELECT stock FROM product_size WHERE product_id=p.product_id ORDER BY eu_size),
               p.category_id, p.manufacturer_id, p.supplier_id,
               EXISTS (SELECT 1
                       FROM order_item oi
                       JOIN orders o ON o.order_id = oi.order_id
                       WHERE oi.product_id = p.product_id
                         AND o.order_date >= @from AND o.order_date < @to) AS ordered_last_month
        FROM product p
        JOIN category c     ON c.category_id = p.category_id
        JOIN manufacturer m ON m.manufacturer_id = p.manufacturer_id
        JOIN supplier s     ON s.supplier_id = p.supplier_id
        """;

    public int CountAll()
    {
        using var conn = _db.Open();
        using var cmd = new NpgsqlCommand("SELECT count(*) FROM product", conn);
        return Convert.ToInt32(cmd.ExecuteScalar());
    }

    public List<Product> Search(string? search, int categoryId, string? sort, bool sale = false, decimal? min = null, decimal? max = null, int brand = 0)
    {
        var sql = SelectSql + """
            
            WHERE (@search = '' OR (p.name ILIKE '%' || @search || '%' OR p.article ILIKE '%' || @search || '%'))
              AND (@category = 0 OR p.category_id = @category)
              AND (@brand = 0 OR p.manufacturer_id = @brand)
            ORDER BY p.product_id
            """;

        using var conn = _db.Open();
        using var cmd = new NpgsqlCommand(sql, conn);
        AddMonthParameters(cmd);
        cmd.Parameters.AddWithValue("search", EscapeLike(search?.Trim() ?? ""));
        cmd.Parameters.AddWithValue("category", categoryId);
        cmd.Parameters.AddWithValue("brand", brand);

        var list = ReadProducts(cmd);
        list.RemoveAll(product => (sale && !product.HasDiscount) ||
            (min.HasValue && product.FinalPrice < min.Value) || (max.HasValue && product.FinalPrice > max.Value));
        return sort switch
        {
            "price-asc" => list.OrderBy(product => product.FinalPrice).ThenBy(product => product.Name).ToList(),
            "price-desc" => list.OrderByDescending(product => product.FinalPrice).ThenBy(product => product.Name).ToList(),
            _ => list
        };
    }

    public Product? GetByArticle(string article)
    {
        using var conn = _db.Open();
        using var cmd = new NpgsqlCommand(SelectSql + " WHERE p.article = @article", conn);
        AddMonthParameters(cmd);
        cmd.Parameters.AddWithValue("article", article);
        return ReadProducts(cmd).FirstOrDefault();
    }

    public Product? GetById(int id)
    {
        using var conn = _db.Open();
        using var cmd = new NpgsqlCommand(SelectSql + " WHERE p.product_id = @id", conn);
        AddMonthParameters(cmd);
        cmd.Parameters.AddWithValue("id", id);
        return ReadProducts(cmd).FirstOrDefault();
    }

    public List<Product> GetByIds(IEnumerable<int> ids)
    {
        var list = ids.ToArray();
        if (list.Length == 0) return new List<Product>();

        using var conn = _db.Open();
        using var cmd = new NpgsqlCommand(SelectSql + " WHERE p.product_id = ANY(@ids) ORDER BY p.name", conn);
        AddMonthParameters(cmd);
        cmd.Parameters.AddWithValue("ids", list);
        return ReadProducts(cmd);
    }

    public List<Product> GetAll()
    {
        using var conn = _db.Open();
        using var cmd = new NpgsqlCommand(SelectSql + " ORDER BY p.name", conn);
        AddMonthParameters(cmd);
        return ReadProducts(cmd);
    }

    private static void AddMonthParameters(NpgsqlCommand cmd)
    {
        var (from, to) = PriceCalculator.PreviousMonth(DateOnly.FromDateTime(DateTime.Today));
        cmd.Parameters.AddWithValue("from", from);
        cmd.Parameters.AddWithValue("to", to);
    }

    // Символы % и _ в строке поиска должны искаться как обычные символы
    private static string EscapeLike(string value) =>
        value.Replace("\\", "\\\\").Replace("%", "\\%").Replace("_", "\\_");

    private static List<Product> ReadProducts(NpgsqlCommand cmd)
    {
        var result = new List<Product>();
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            var sizes = reader.GetFieldValue<int[]>(10);
            var stocks = reader.GetFieldValue<int[]>(11);
            result.Add(new Product
            {
                Id = reader.GetInt32(0),
                Article = reader.GetString(1),
                Name = reader.GetString(2),
                Category = reader.GetString(3),
                Manufacturer = reader.GetString(4),
                Supplier = reader.GetString(5),
                Unit = reader.GetString(6),
                Price = reader.GetDecimal(7),
                Description = reader.IsDBNull(8) ? null : reader.GetString(8),
                Photo = reader.IsDBNull(9) ? null : reader.GetString(9),
                Sizes = sizes.Select((size, i) => new ShoeSize(size, stocks[i])).ToArray(),
                CategoryId = reader.GetInt32(12),
                ManufacturerId = reader.GetInt32(13),
                SupplierId = reader.GetInt32(14),
                OrderedLastMonth = reader.GetBoolean(15)
            });
        }
        return result;
    }
}
