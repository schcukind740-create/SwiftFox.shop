using Npgsql;
using ShoeShop.Web.Models;

namespace ShoeShop.Web.Data;

/// <summary>Справочники для выпадающих списков.</summary>
public class LookupRepository
{
    private readonly Database _db;

    public LookupRepository(Database db) => _db = db;

    public List<Category> Categories() =>
        Read("SELECT category_id, name FROM category ORDER BY name",
             r => new Category(r.GetInt32(0), r.GetString(1)));

    public List<PickupPoint> PickupPoints() =>
        Read("SELECT point_id, address FROM pickup_point ORDER BY address",
             r => new PickupPoint(r.GetInt32(0), r.GetString(1)));

    public List<OrderStatus> Statuses() =>
        Read("SELECT status_id, name FROM order_status ORDER BY status_id",
             r => new OrderStatus(r.GetInt32(0), r.GetString(1)));

    public List<Client> Clients() =>
        Read("""
             SELECT u.user_id, concat_ws(' ', u.last_name, u.first_name, u.patronymic)
             FROM app_user u
             WHERE u.active
             ORDER BY u.last_name, u.first_name
             """,
             r => new Client(r.GetInt32(0), r.GetString(1)));

    private List<T> Read<T>(string sql, Func<NpgsqlDataReader, T> map)
    {
        using var conn = _db.Open();
        using var cmd = new NpgsqlCommand(sql, conn);
        using var reader = cmd.ExecuteReader();
        var list = new List<T>();
        while (reader.Read()) list.Add(map(reader));
        return list;
    }
}
