-- SwiftFox.shop. Выполнить после 03_store.sql.
-- Повторный запуск сохраняет уже заведённые модели и их остатки.
BEGIN;

INSERT INTO manufacturer (name) VALUES ('ASICS') ON CONFLICT (name) DO NOTHING;
SELECT set_config('swiftfox.stock_reason', 'Пополнение каталога', true);

WITH seed (brand, name, article, category, price, description, photo, stock) AS (
    VALUES
        ('Nike', 'Nike Air Max 90', 'CN8490-100', 'Ретро', 15990, 'Классический силуэт Air Max с видимой амортизацией в пятке.', 'catalog-cn8490-100.webp', 3),
        ('New Balance', 'New Balance 574 Core', 'ML574EVB', 'Ретро', 12490, 'Повседневная модель с сочетанием замши и сетки.', 'catalog-ml574evb.webp', 10),
        ('PUMA', 'PUMA Suede Classic XXI', '374915-01', 'Ретро', 10990, 'Классические низкие кеды из замши с контрастной боковой полосой.', 'catalog-374915-01.webp', 17),
        ('ASICS', 'ASICS GEL-KAYANO 14', '1201A019-108', 'Ретро', 18990, 'Сетчатый верх и открытые вставки GEL в ретро-силуэте.', 'catalog-1201a019-108.webp', 6),
        ('Nike', 'Nike Pegasus 41', 'FD2722-016', 'Беговые', 15990, 'Беговая пара с сетчатым верхом и амортизацией для ежедневных тренировок.', 'catalog-fd2722-016.webp', 13),
        ('New Balance', 'New Balance 990v6', 'M990GL6', 'Повседневные', 23990, 'Серые кроссовки с сеткой, накладками из замши и объёмной подошвой.', 'catalog-m990gl6.webp', 20),
        ('PUMA', 'PUMA CA Pro Classic', '380190-01', 'Повседневные', 11290, 'Низкие кеды в баскетбольной стилистике с перфорацией на носке.', 'catalog-380190-01.webp', 9),
        ('ASICS', 'ASICS GEL-1130', '1201A256-116', 'Ретро', 13990, 'Повседневный силуэт из архивной беговой линейки ASICS.', 'catalog-1201a256-116.webp', 16),
        ('Nike', 'Nike Dunk Low Retro', 'DD1391-100', 'Ретро', 14490, 'Баскетбольный силуэт в чёрно-белой расцветке.', 'catalog-dd1391-100.webp', 5),
        ('New Balance', 'New Balance 993 Core', 'MR993GL', 'Повседневные', 24490, 'Модель семейства 99X с сетчатым верхом и замшевыми накладками.', 'catalog-mr993gl.webp', 12),
        ('PUMA', 'PUMA Deviate NITRO 4', '312123-01', 'Беговые', 18490, 'Шоссейная модель с пеной NITROFOAM и пластиной PWRPLATE.', 'catalog-312123-01.webp', 19),
        ('ASICS', 'ASICS GEL-NYC', '1201A789-001', 'Повседневные', 16990, 'Уличная модель, силуэт которой сочетает элементы архивных беговых кроссовок.', 'catalog-1201a789-001.webp', 8),
        ('Nike', 'Nike Zoom Vomero 5', 'BV1358-001', 'Повседневные', 17490, 'Многослойный верх с сеткой и характерным каркасом в средней части.', 'catalog-bv1358-001.webp', 15),
        ('New Balance', 'New Balance 928v3', 'MW928BK3', 'Повседневные', 14690, 'Пара для ходьбы с чёрным верхом и устойчивой подошвой.', 'catalog-mw928bk3.webp', 4),
        ('PUMA', 'PUMA Velocity NITRO 4', '311141-01', 'Беговые', 14990, 'Беговая модель для регулярных тренировок на шоссе.', 'catalog-311141-01.webp', 11),
        ('ASICS', 'ASICS JAPAN S', '1201A173-126', 'Ретро', 11990, 'Низкий силуэт с баскетбольными корнями и лаконичными боковыми полосами.', 'catalog-1201a173-126.webp', 18),
        ('Nike', 'Nike Cortez Leather', 'DM4044-001', 'Ретро', 11990, 'Низкие кроссовки с кожаным верхом и пилообразной подошвой.', 'catalog-dm4044-001.webp', 7),
        ('New Balance', 'New Balance 608v5', 'MX608AB5', 'Повседневные', 11690, 'Массивная тренировочная модель с кожаным верхом и амортизацией.', 'catalog-mx608ab5.webp', 14),
        ('PUMA', 'PUMA RS-X Efekt PRM', '390776-42', 'Повседневные', 13990, 'Объёмная модель с многослойным верхом и скульптурной подошвой.', 'catalog-390776-42.webp', 3),
        ('ASICS', 'ASICS GEL-QUANTUM 180', '1201A063-001', 'Повседневные', 15790, 'Городские кроссовки с заметными амортизирующими вставками GEL.', 'catalog-1201a063-001.webp', 10),
        ('Nike', 'Nike Air Max Dn', 'DV3337-002', 'Повседневные', 18490, 'Тёмная модель с сетчатым верхом и технологией Dynamic Air.', 'catalog-dv3337-002.webp', 17),
        ('New Balance', 'New Balance 1906R', 'M1906RER', 'Ретро', 16990, 'Многослойный верх и профиль в стиле беговых моделей 2000-х.', 'catalog-m1906rer.webp', 6),
        ('PUMA', 'PUMA MagMax NITRO 2', '312125-11', 'Беговые', 17990, 'Беговая модель для длительных тренировок с высокой подошвой.', 'catalog-312125-11.webp', 13),
        ('New Balance', 'New Balance 740', 'U740WM2', 'Ретро', 13690, 'Сетчатая модель в архивной беговой эстетике.', 'catalog-u740wm2.webp', 20),
        ('New Balance', 'New Balance 327', 'W327628', 'Повседневные', 12990, 'Низкая модель с крупной боковой буквой N и выступающим протектором.', 'catalog-w327628.webp', 9)
),
added AS (
    INSERT INTO product (article, name, category_id, manufacturer_id, supplier_id, unit, price, description, photo)
    SELECT seed.article, seed.name, category.category_id, manufacturer.manufacturer_id, supplier.supplier_id,
           'пара', seed.price, seed.description, seed.photo
    FROM seed
    JOIN category ON category.name = seed.category
    JOIN manufacturer ON manufacturer.name = seed.brand
    JOIN supplier ON supplier.name = 'SwiftFox Distribution'
    ON CONFLICT (article) DO NOTHING
    RETURNING product_id, article
)
INSERT INTO product_size (product_id, eu_size, stock)
SELECT added.product_id, sizes.eu_size,
       seed.stock / 7 + CASE WHEN sizes.priority <= seed.stock % 7 THEN 1 ELSE 0 END
FROM added
JOIN seed USING (article)
CROSS JOIN unnest(ARRAY[42, 41, 43, 40, 44, 39, 38]) WITH ORDINALITY AS sizes(eu_size, priority);

COMMIT;
