-- Выполнить в psql из каталога database, после 01_schema.sql.
\set ON_ERROR_STOP on
BEGIN;
\copy role (role_id,name) FROM 'import/roles.csv' WITH (FORMAT csv, HEADER, ENCODING 'UTF8')
\copy app_user (role_id,last_name,first_name,patronymic,login) FROM 'import/users.csv' WITH (FORMAT csv, HEADER, ENCODING 'UTF8')
\copy supplier (supplier_id,name) FROM 'import/suppliers.csv' WITH (FORMAT csv, HEADER, ENCODING 'UTF8')
\copy manufacturer (manufacturer_id,name) FROM 'import/manufacturers.csv' WITH (FORMAT csv, HEADER, ENCODING 'UTF8')
\copy category (category_id,name) FROM 'import/categories.csv' WITH (FORMAT csv, HEADER, ENCODING 'UTF8')
\copy pickup_point (point_id,address) FROM 'import/pickup_points.csv' WITH (FORMAT csv, HEADER, ENCODING 'UTF8')
\copy order_status (name) FROM 'import/order_statuses.csv' WITH (FORMAT csv, HEADER, ENCODING 'UTF8')
\copy product (category_id,manufacturer_id,supplier_id,article,name,unit,price,stock,description,photo) FROM 'import/products.csv' WITH (FORMAT csv, HEADER, ENCODING 'UTF8')
SELECT setval(pg_get_serial_sequence('role','role_id'),       (SELECT max(role_id) FROM role));
SELECT setval(pg_get_serial_sequence('supplier','supplier_id'), (SELECT max(supplier_id) FROM supplier));
SELECT setval(pg_get_serial_sequence('manufacturer','manufacturer_id'), (SELECT max(manufacturer_id) FROM manufacturer));
SELECT setval(pg_get_serial_sequence('category','category_id'), (SELECT max(category_id) FROM category));
SELECT setval(pg_get_serial_sequence('pickup_point','point_id'), (SELECT max(point_id) FROM pickup_point));

CREATE TEMP TABLE import_order (
    buyer text,
    product_article text,
    month_offset integer,
    day_offset integer,
    qty integer,
    unit_price numeric(12,2),
    point_id integer,
    code integer,
    status_name text
) ON COMMIT DROP;
\copy import_order FROM 'import/orders.csv' WITH (FORMAT csv, HEADER, ENCODING 'UTF8')
INSERT INTO orders (user_id,point_id,status_id,order_date,delivery_date,pickup_code)
SELECT u.user_id, i.point_id, s.status_id, d.ordered, d.ordered + 3, i.code
FROM import_order i
JOIN app_user u ON u.login = i.buyer
JOIN order_status s ON s.name = i.status_name
CROSS JOIN LATERAL (
    SELECT (date_trunc('month', current_date) + make_interval(months => i.month_offset))::date + i.day_offset AS ordered
) d;
INSERT INTO order_item (order_id,product_id,quantity,price)
SELECT o.order_id,p.product_id,i.qty,i.unit_price
FROM import_order i
JOIN orders o ON o.pickup_code = i.code
JOIN product p ON p.article = i.product_article;
-- В import/products.csv указаны остатки после исторических заказов.
COMMIT;
