BEGIN;
ALTER TABLE app_user ADD COLUMN active boolean NOT NULL DEFAULT true;
ALTER TABLE orders ADD COLUMN payment_method text NOT NULL DEFAULT 'pickup'
    CHECK (payment_method IN ('pickup', 'demo'));

CREATE TABLE product_size (
    product_id integer NOT NULL REFERENCES product,
    eu_size integer NOT NULL CHECK (eu_size BETWEEN 35 AND 49),
    stock integer NOT NULL CHECK (stock >= 0),
    PRIMARY KEY (product_id, eu_size)
);
INSERT INTO product_size (product_id, eu_size, stock)
SELECT p.product_id, x.eu_size, p.stock / 7 + CASE WHEN x.priority <= p.stock % 7 THEN 1 ELSE 0 END
FROM product p
CROSS JOIN unnest(ARRAY[42, 41, 43, 40, 44, 39, 38]) WITH ORDINALITY AS x(eu_size, priority);

ALTER TABLE order_item ADD COLUMN eu_size integer NOT NULL DEFAULT 42;
ALTER TABLE order_item DROP CONSTRAINT order_item_pkey;
ALTER TABLE order_item ADD PRIMARY KEY (order_id, product_id, eu_size);
ALTER TABLE order_item ADD FOREIGN KEY (product_id, eu_size) REFERENCES product_size;
ALTER TABLE order_item ALTER COLUMN eu_size DROP DEFAULT;
ALTER TABLE product DROP COLUMN stock;

CREATE TABLE inventory_movement (
    movement_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    product_id integer NOT NULL,
    eu_size integer NOT NULL,
    delta integer NOT NULL CHECK (delta <> 0),
    stock_after integer NOT NULL CHECK (stock_after >= 0),
    reason text NOT NULL,
    changed_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (product_id, eu_size) REFERENCES product_size
);
CREATE INDEX inventory_movement_recent ON inventory_movement(changed_at DESC, movement_id DESC);
CREATE FUNCTION record_inventory_movement() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE old_stock integer;
BEGIN
    old_stock := CASE WHEN TG_OP = 'INSERT' THEN 0 ELSE OLD.stock END;
    IF NEW.stock <> old_stock THEN
        INSERT INTO inventory_movement (product_id, eu_size, delta, stock_after, reason)
        VALUES (NEW.product_id, NEW.eu_size, NEW.stock - old_stock, NEW.stock,
                COALESCE(NULLIF(current_setting('swiftfox.stock_reason', true), ''), 'Корректировка склада'));
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER product_size_movement AFTER INSERT OR UPDATE OF stock ON product_size
FOR EACH ROW EXECUTE FUNCTION record_inventory_movement();
COMMIT;
